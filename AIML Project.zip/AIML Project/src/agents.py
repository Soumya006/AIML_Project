import sys
import os
import time
from planners import bfs, ucs, astar, local_search
from utils import load_grid, print_grid

# Ensure the result folder exists
os.makedirs("result", exist_ok=True)

def run_planner(planner_func, grid, start, goal, planner_name, *args):
    """Run a planner with timing and print/log results."""
    start_time = time.time()
    result = planner_func(grid, start, goal, *args)  # handle extra args if needed
    end_time = time.time()
    execution_time = end_time - start_time

    # Check number of returned values
    if len(result) == 2:
        path, cost = result
        nodes_expanded = "N/A"
    else:
        path, cost, nodes_expanded = result

    print(f"\n--- {planner_name.upper()} RESULTS ---")
    print(f"Start point: {start}")
    print(f"Goal point: {goal}")
    print(f"Path cost: {cost}")
    print(f"Nodes expanded: {nodes_expanded}")
    print(f"Execution time: {execution_time:.6f} seconds")
    print("\nPath taken:")
    print_grid(grid, path)

    # Log results
    with open("result/logs.txt", "a") as f:
        f.write(f"Planner: {planner_name.upper()}\n")
        f.write(f"Map: {mapfile}\n")
        f.write(f"Start: {start}\n")
        f.write(f"Goal: {goal}\n")
        f.write(f"Path cost: {cost}\n")
        f.write(f"Nodes expanded: {nodes_expanded}\n")
        f.write(f"Execution time: {execution_time:.6f} seconds\n")
        f.write("-" * 40 + "\n")

def main():
    if len(sys.argv) < 3:
        print("Usage: python agents.py <mapfile> <planner_name>")
        print("Planner options: bfs / ucs / astar / local")
        return

    global mapfile
    mapfile = sys.argv[1]
    planner_name = sys.argv[2].lower()

    # Load grid
    grid, start, goal = load_grid(mapfile)
    print("Map loaded:")
    print_grid(grid)

    # Define dynamic obstacles for local search
    dynamic_obstacles = []  # adjust as needed for your local_search

    # Run only the planner specified
    if planner_name == "bfs":
        run_planner(bfs, grid, start, goal, "bfs")
    elif planner_name == "ucs":
        run_planner(ucs, grid, start, goal, "ucs")
    elif planner_name == "astar":
        run_planner(astar, grid, start, goal, "astar")
    elif planner_name == "local":
        run_planner(local_search, grid, start, goal, "local", dynamic_obstacles)
    else:
        print("Invalid planner name! Choose from: bfs, ucs, astar, local")
        return

if __name__ == "__main__":
    main()