# Description
The delivery agent in this project finds the shortest path from a start location to a goal on a 2D grid map using a number of search algorithms, such as **Breadth-First Search (BFS), **Uniform Cost Search (UCS), **A Search*, and **Local Search*. The agent calculates the path's cost, steers clear of obstructions, and displays the path graphically on the grid.

# Features: Local Search pathfinding, BFS, UCS, and A*
The path is represented visually in a grid; the total cost and path length are output; and multiple map files (Dynamic, Small, Medium, Large) are supported.

# Installation / Setup
```bash
git clone <your-repo-url>
cd AIML_Project/src

How to Run

python agents.py ../Maps/small.txt bfs         # Run BFS on Small map
python agents_dynamic.py ../Maps/dynamic.txt astar  # Run A* on Dynamic map
python agents.py ../Maps/medium.txt ucs       # Run UCS on Medium map
python agents.py ../Maps/large.txt local      # Run Local Search on Large map

Output Example (BFS)

Map loaded:
 1  1  1  1  1 
 1  X  1  1  1
 1  1  1  X  1
 1  1  1  1  1
 1  1  1  1  1


--- BFS RESULTS ---
Start point: (0, 0)
Goal point: (4, 4)
Path cost: 9
Nodes expanded: N/A
Execution time: 0.000377 seconds

Path taken:
 *  1  1  1  1
 *  X  1  1  1
 *  1  1  X  1
 *  1  1  1  1
 *  *  *  *  *

Directory Structure

AIML_Project/
├── Maps/
│   ├── dynamic.txt
│   ├── large.txt
│   ├── medium.txt
│   └── small.txt
├── Src/
├── Result/
│   └── logs.txt
│   ├── agent_dynamic.py
│   ├── agents.py
│   ├── planners.py
│   └── utils.py
├── README.md
└── Report.pdf

Upcoming Projects

Make the agent move in a step-by-step animation.
Include weighted maps for A* and UCS.
Visual output that is colored for improved clarity
Enhance the heuristics for local searches

# All the results are in reult/logs.txt

Author

Soumya Pandey